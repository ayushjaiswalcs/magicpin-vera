"""Build 30 static fixture outputs using the company's unmodified generated pairs."""
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from bot import compose

def read(kind, identifier):
    return json.loads((ROOT / 'dataset' / kind / (identifier + '.json')).read_text())

rows=[]
for pair in json.loads((ROOT / 'dataset/test_pairs.json').read_text())['pairs']:
    merchant=read('merchants', pair['merchant_id'])
    category=read('categories', merchant['category_slug'])
    trigger=read('triggers', pair['trigger_id'])
    customer=read('customers', pair['customer_id']) if pair.get('customer_id') else None
    rows.append(dict(test_id=pair['test_id'], **compose(category, merchant, trigger, customer)))
(ROOT / 'submission.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False)+'\n' for r in rows))
print(f"Wrote {len(rows)} fixture rows; {sum(bool(r['body']) for r in rows)} messages, {sum(not r['body'] for r in rows)} documented suppressions.")

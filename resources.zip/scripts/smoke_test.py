"""Unscored HTTP smoke test using the company's actual BotClient transport.
Resets the target test server. Use only before judge warmup.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('company_judge', ROOT/'official/judge_simulator.py')
judge=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=judge
spec.loader.exec_module(judge)
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--url', default='http://localhost:8080')
args=parser.parse_args()
client=judge.BotClient(args.url)
checks=[]
def call(method,path,data=None):
    result,err,lat=client._request(method,path,body_dict=data)
    assert not err,(path,err)
    assert result is not None,path
    return result,lat

def check(name,ok,**extra):
    assert ok,name
    checks.append(dict(check=name,passed=True,**extra))
    print('PASS:',name)

call('POST','/v1/teardown',{})
health,_=call('GET','/v1/healthz')
check('Fresh server',sum(health['contexts_loaded'].values())==0)
for folder,scope,key in [('categories','category','slug'),('merchants','merchant','merchant_id'),('customers','customer','customer_id'),('triggers','trigger','id')]:
    for path in sorted((ROOT/'dataset'/folder).glob('*.json')):
        p=json.loads(path.read_text())
        r,err,lat=client.push_context(scope,p[key],1,p)
        assert r.get('accepted'),(path,r,err)
health,_=call('GET','/v1/healthz')
check('Complete dataset loaded',health['contexts_loaded']==dict(category=5,merchant=50,customer=200,trigger=100))
tid='trg_001_research_digest_dentists'
r,lat=call('POST','/v1/tick',dict(now='2026-04-26T10:00:00Z',available_triggers=[tid]))
check('Tick produces grounded template',len(r['actions'])==1 and bool(r['actions'][0].get('template_name')),latency_ms=round(lat,2))
a=r['actions'][0]
def reply(msg,turn):
    return call('POST','/v1/reply',dict(conversation_id=a['conversation_id'],merchant_id=a['merchant_id'],from_role='merchant',message=msg,turn_number=turn,received_at=f'2026-04-26T10:{turn:02d}:00Z'))[0]
r=reply('Ok lets do it. Whats next?',2)
check('Acceptance immediately produces draft',r['action']=='send' and 'draft' in r['body'])
p=json.loads((ROOT/'dataset/categories/dentists.json').read_text())
p['digest'][0]['summary']='UPDATED SYNTHETIC SUMMARY: review the revised context.'
client.push_context('category','dentists',2,p)
r=reply('Please send the updated summary',3)
check('Mid-conversation context adaptation','UPDATED SYNTHETIC SUMMARY' in r['body'])
r=reply('STOP',4)
check('Opt-out ends conversation',r['action']=='end')
r=reply('YES',5)
check('Ended conversation stays ended',r['action']=='end')
r,_=call('POST','/v1/tick',dict(now='2026-04-26T10:20:00Z',available_triggers=['trg_022_cde_webinar_dentists']))
check('Opt-out blocks other triggers',r['actions']==[])
# Separate customer consent from merchant opt-out.
r,_=call('POST','/v1/tick',dict(now='2026-11-01T10:00:00Z',available_triggers=['trg_003_recall_due_priya']))
check('Customer reminder attributed to merchant',len(r['actions'])==1 and r['actions'][0]['send_as']=='merchant_on_behalf')
a=r['actions'][0]
r,_=call('POST','/v1/reply',dict(conversation_id=a['conversation_id'],merchant_id=a['merchant_id'],customer_id=a['customer_id'],from_role='customer',message='YES',turn_number=2,received_at='2026-11-01T10:01:00Z'))
check('No false booking on acceptance','confirm' in r.get('body',''))
call('POST','/v1/teardown',{})
r,_=call('GET','/v1/healthz')
check('Teardown wipes state',sum(r['contexts_loaded'].values())==0)
report=dict(ran_at=datetime.now(timezone.utc).isoformat(),target=args.url,transport='Unmodified company judge_simulator.BotClient',llm_scoring_run=False,checks=checks)
(ROOT/'test-results').mkdir(exist_ok=True)
(ROOT/'test-results/http-smoke.json').write_text(json.dumps(report,indent=2))
print(f'{len(checks)} HTTP checks passed. No LLM judge score was computed.')

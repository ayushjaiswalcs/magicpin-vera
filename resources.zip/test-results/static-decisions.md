# Static fixture decisions

| Test | Decision | Reason |
| --- | --- | --- |
| T01 | Send | Explicit planning intent: provide an immediate draft instead of requalifying |
| T02 | Send | Explicit planning intent: provide an immediate draft instead of requalifying |
| T03 | Suppress | No matching opt-in scope for this trigger |
| T04 | Suppress | No matching opt-in scope for this trigger |
| T05 | Send | category_seasonal; facts from trigger and latest merchant/category context; one primary CTA; no external action claimed |
| T06 | Send | cde_opportunity; exact source-linked item; synthetic supplied claims are attributed, not externally verified |
| T07 | Suppress | Customer channel is not WhatsApp |
| T08 | Suppress | No matching opt-in scope for this trigger |
| T09 | Send | competitor_opened; facts from trigger and latest merchant/category context; one primary CTA; no external action claimed |
| T10 | Suppress | Competitor identity missing |
| T11 | Send | Weekly curiosity prompt anchored to this business; one question |
| T12 | Send | Weekly curiosity prompt anchored to this business; one question |
| T13 | Send | Customer customer_lapsed_hard; matching consent checked; dates and preferences from context; no booking or delivery claim |
| T14 | Suppress | No matching opt-in scope for this trigger |
| T15 | Suppress | No matching opt-in scope for this trigger |
| T16 | Send | dormant_with_vera; facts from trigger and latest merchant/category context; one primary CTA; no external action claimed |
| T17 | Send | dormant_with_vera; facts from trigger and latest merchant/category context; one primary CTA; no external action claimed |
| T18 | Send | festival_upcoming; facts from trigger and latest merchant/category context; one primary CTA; no external action claimed |
| T19 | Suppress | Event facts missing |
| T20 | Send | gbp_unverified; facts from trigger and latest merchant/category context; one primary CTA; no external action claimed |
| T21 | Send | ipl_match_today; facts from trigger and latest merchant/category context; one primary CTA; no external action claimed |
| T22 | Send | milestone_reached; facts from trigger and latest merchant/category context; one primary CTA; no external action claimed |
| T23 | Suppress | Milestone counts missing; do not fabricate achievement |
| T24 | Send | perf_dip; facts from trigger and latest merchant/category context; one primary CTA; no external action claimed |
| T25 | Suppress | No supporting performance change in latest context |
| T26 | Send | perf_spike; facts from trigger and latest merchant/category context; one primary CTA; no external action claimed |
| T27 | Send | perf_spike; facts from trigger and latest merchant/category context; one primary CTA; no external action claimed |
| T28 | Send | Customer recall_due; matching consent checked; dates and preferences from context; no booking or delivery claim |
| T29 | Suppress | No matching opt-in scope for this trigger |
| T30 | Send | regulation_change; exact source-linked item; synthetic supplied claims are attributed, not externally verified |

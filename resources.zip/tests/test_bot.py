import copy
import json
from pathlib import Path
import unittest
from concurrent.futures import ThreadPoolExecutor
from bot import Engine, APIError, compose, slots_for

ROOT=Path(__file__).resolve().parents[1]
NOW='2026-04-26T10:00:00Z'

def load(folder, name):
    return json.loads((ROOT/'dataset'/folder/(name+'.json')).read_text())

class BotTests(unittest.TestCase):
    def setUp(self):
        self.e=Engine()
        self.m=load('merchants','m_001_drmeera_dentist_delhi')
        self.cat=load('categories','dentists')
        self.t=load('triggers','trg_001_research_digest_dentists')
        for scope,payload,key in [('merchant',self.m,'merchant_id'),('category',self.cat,'slug'),('trigger',self.t,'id')]:
            self.push(scope,payload,key)

    def push(self,scope,payload,key,version=1):
        return self.e.dispatch('POST','/v1/context',dict(scope=scope,context_id=payload[key],version=version,payload=payload))

    def tick(self, tids=None, now=NOW):
        return self.e.dispatch('POST','/v1/tick',dict(now=now, available_triggers=tids or [self.t['id']]))[1]['actions']

    def reply(self,a,msg='Yes, please send the draft',turn=2,at='2026-04-26T10:01:00Z'):
        return self.e.dispatch('POST','/v1/reply',dict(conversation_id=a['conversation_id'],merchant_id=a['merchant_id'],customer_id=a['customer_id'],from_role='customer' if a['customer_id'] else 'merchant',message=msg,turn_number=turn,received_at=at))[1]

    def test_health_counts(self):
        self.assertEqual(self.e.dispatch('GET','/v1/healthz')[1]['contexts_loaded'],dict(category=1,merchant=1,customer=0,trigger=1))

    def test_stale_and_duplicate_versions(self):
        self.assertEqual(self.push('merchant',self.m,'merchant_id')[0],409)
        self.assertEqual(self.push('merchant',self.m,'merchant_id',3)[0],200)
        self.assertEqual(self.push('merchant',self.m,'merchant_id',2)[0],409)

    def test_context_replacement_not_merge(self):
        newer=dict(merchant_id=self.m['merchant_id'],category_slug='dentists',identity={'name':'Changed'})
        self.push('merchant',newer,'merchant_id',2)
        self.assertNotIn('offers',self.e.get('merchant',self.m['merchant_id']))

    def test_context_id_mismatch(self):
        with self.assertRaises(APIError):
            self.e.dispatch('POST','/v1/context',dict(scope='merchant',context_id='wrong',version=1,payload=self.m))

    def test_invalid_scope(self):
        with self.assertRaises(APIError):
            self.e.dispatch('POST','/v1/context',dict(scope='secret',context_id='x',version=1,payload={}))

    def test_compose_deterministic_and_inputs_unchanged(self):
        before=copy.deepcopy([self.cat,self.m,self.t])
        self.assertEqual(compose(self.cat,self.m,self.t),compose(self.cat,self.m,self.t))
        self.assertEqual(before,[self.cat,self.m,self.t])

    def test_template_render_exactly_matches_body(self):
        a=self.tick()[0]
        self.assertEqual(a['body'],f"{a['template_params'][0]}, {a['template_params'][1]} {a['template_params'][2]}".strip())
        self.assertIn('YES',a['body'])
        self.assertIn('Source:',a['body'])

    def test_repeat_tick_is_silent(self):
        self.assertEqual(len(self.tick()),1)
        self.assertEqual(self.tick(),[])

    def test_expired_trigger_is_silent(self):
        self.assertEqual(self.tick(now='2026-09-27T10:00:00Z'),[])

    def test_trigger_not_before(self):
        self.t['not_before']='2026-04-27T00:00:00Z'
        self.push('trigger',self.t,'id',2)
        self.assertEqual(self.tick(),[])

    def test_missing_trigger_or_category(self):
        self.assertEqual(self.tick(['missing']),[])
        self.e.contexts['category'].clear()
        self.assertEqual(self.tick(),[])

    def test_no_fabricated_missing_digest(self):
        self.t['payload']['top_item_id']='not-in-context'
        self.push('trigger',self.t,'id',2)
        self.assertEqual(self.tick(),[])

    def test_latest_context_used_for_first_message(self):
        self.cat['digest'][0]['title']='Injected new research title'
        self.push('category',self.cat,'slug',2)
        self.assertIn('Injected new research title',self.tick()[0]['body'])

    def test_latest_context_used_for_reply(self):
        a=self.tick()[0]
        self.cat['digest'][0]['summary']='Injected changed summary'
        self.push('category',self.cat,'slug',2)
        self.assertIn('Injected changed summary',self.reply(a)['body'])

    def test_yes_delivers_draft(self):
        r=self.reply(self.tick()[0])
        self.assertEqual(r['action'],'send')
        self.assertIn('draft',r['body'])
        self.assertNotIn('booked',r['body'])

    def test_autoreply_wait_then_end(self):
        a=self.tick()[0];message='Thank you for contacting us! Our team will respond shortly.'
        self.assertEqual(self.reply(a,message)['action'],'wait')
        self.assertEqual(self.reply(a,message,3,'2026-04-26T10:02:00Z')['action'],'end')

    def test_stop_suppresses_future_triggers(self):
        a=self.tick()[0]
        self.assertEqual(self.reply(a,'STOP')['action'],'end')
        self.t.update(id='new',suppression_key='new')
        self.push('trigger',self.t,'id')
        self.assertEqual(self.tick(['new'],'2026-04-26T12:00:00Z'),[])

    def test_decline_ends(self):
        self.assertEqual(self.reply(self.tick()[0],'Not interested')['action'],'end')

    def test_busy_sets_actual_cooldown(self):
        a=self.tick()[0]
        self.assertEqual(self.reply(a,'Busy, later')['wait_seconds'],1800)
        self.t.update(id='new',suppression_key='new')
        self.push('trigger',self.t,'id')
        self.assertEqual(self.tick(['new'],'2026-04-26T10:10:00Z'),[])

    def test_join_skips_qualification(self):
        r=self.reply(self.tick()[0],'I want to join magicpin')
        self.assertIn('Onboarding checklist',r['body'])
        self.assertNotIn('would you',r['body'].lower())

    def test_offtopic_scope(self):
        self.assertIn('accountant',self.reply(self.tick()[0],'Can you file my GST?')['body'])

    def test_unknown_conversation_rejected(self):
        with self.assertRaises(APIError) as ctx:
            self.e.dispatch('POST','/v1/reply',dict(conversation_id='invented'))
        self.assertEqual(ctx.exception.status,404)

    def test_replayed_reply_idempotent(self):
        a=self.tick()[0]
        self.assertEqual(self.reply(a),self.reply(a))
        self.assertEqual(len(self.e.conversations[a['conversation_id']]['received']),1)

    def test_conflicting_turn_rejected(self):
        a=self.tick()[0];self.reply(a)
        with self.assertRaises(APIError) as ctx:self.reply(a,'Different')
        self.assertEqual(ctx.exception.status,409)

    def test_out_of_order_timestamp(self):
        a=self.tick()[0]
        with self.assertRaises(APIError):self.reply(a,at='2026-04-25T00:00:00Z')

    def test_wrong_recipient_rejected(self):
        a=self.tick()[0]
        with self.assertRaises(APIError):
            self.e.dispatch('POST','/v1/reply',dict(conversation_id=a['conversation_id'],merchant_id='other',from_role='merchant',message='YES',turn_number=2,received_at=NOW))

    def customer_setup(self):
        customer=load('customers','c_001_priya_for_m001')
        trigger=load('triggers','trg_003_recall_due_priya')
        self.push('customer',customer,'customer_id')
        self.push('trigger',trigger,'id')
        return customer,trigger

    def test_customer_consent_and_send_as(self):
        c,t=self.customer_setup()
        a=self.tick([t['id']],'2026-11-01T10:00:00Z')[0]
        self.assertEqual(a['send_as'],'merchant_on_behalf')
        self.assertIn('Priya',a['body'])
        self.assertNotIn('₹',a['body']) # reminder-only consent cannot be used for promotional offers
        self.assertIn('YES',a['body'])

    def test_no_consent_no_send(self):
        c,t=self.customer_setup();c['consent']['scope']=[]
        self.push('customer',c,'customer_id',2)
        self.assertEqual(self.tick([t['id']],'2026-11-01T10:00:00Z'),[])

    def test_wrong_customer_merchant(self):
        c,t=self.customer_setup();c['merchant_id']='other'
        self.push('customer',c,'customer_id',2)
        self.assertEqual(self.tick([t['id']],'2026-11-01T10:00:00Z'),[])

    def test_future_consent_not_valid(self):
        c,t=self.customer_setup();c['consent']['opted_in_at']='2027-01-01'
        self.push('customer',c,'customer_id',2)
        self.assertEqual(self.tick([t['id']],'2026-11-01T10:00:00Z'),[])

    def test_revoked_consent_stops_open_conversation(self):
        c,t=self.customer_setup();a=self.tick([t['id']],'2026-11-01T10:00:00Z')[0]
        c['consent']['revoked_at']='2026-11-01T10:01:00Z'
        self.push('customer',c,'customer_id',2)
        self.assertEqual(self.reply(a,at='2026-11-01T10:02:00Z')['action'],'end')

    def test_customer_acceptance_not_false_booking(self):
        c,t=self.customer_setup();a=self.tick([t['id']],'2026-11-01T10:00:00Z')[0]
        r=self.reply(a,'1',at='2026-11-01T10:01:00Z')
        self.assertIn('Thu 05 Nov',r['body']) # seed label incorrectly says Wednesday
        self.assertIn('confirm',r['body'])

    def test_dedup_is_per_recipient_and_action_cap(self):
        ids=[]
        for i in range(25):
            m=copy.deepcopy(self.m);m['merchant_id']=f'm_test_{i}'
            self.push('merchant',m,'merchant_id')
            t=copy.deepcopy(self.t);t.update(id=f'test_{i}',merchant_id=m['merchant_id'])
            self.push('trigger',t,'id');ids.append(t['id'])
        self.assertEqual(len(self.tick(ids)),20)
        self.assertEqual(len(self.tick(ids)),5)

    def test_concurrent_ticks_only_send_once(self):
        with ThreadPoolExecutor(max_workers=10) as pool:
            rows=list(pool.map(lambda _:self.tick(),range(10)))
        self.assertEqual(sum(map(len,rows)),1)

    def test_teardown_clears_all_state(self):
        a=self.tick()[0];self.reply(a,'STOP')
        self.e.dispatch('POST','/v1/teardown',{})
        self.assertFalse(self.e.conversations or self.e.sent_keys or self.e.opted_out)
        self.assertEqual(sum(self.e.dispatch('GET','/v1/healthz')[1]['contexts_loaded'].values()),0)

    def test_all_dataset_compositions_are_structured(self):
        for path in (ROOT/'dataset/triggers').glob('*.json'):
            t=json.loads(path.read_text());m=load('merchants',t['merchant_id']);cat=load('categories',m['category_slug'])
            c=load('customers',t['customer_id']) if t.get('customer_id') else None
            r=compose(cat,m,t,c)
            self.assertTrue({'body','cta','send_as','suppression_key','rationale'} <= r.keys())
            self.assertTrue(r['body'] or r.get('suppressed'))

if __name__=='__main__':unittest.main(verbosity=2)
